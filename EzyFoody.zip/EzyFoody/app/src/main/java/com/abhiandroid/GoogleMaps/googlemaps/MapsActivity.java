package com.abhiandroid.GoogleMaps.googlemaps;

import android.app.Activity;

public class MapsActivity extends Activity {
}
