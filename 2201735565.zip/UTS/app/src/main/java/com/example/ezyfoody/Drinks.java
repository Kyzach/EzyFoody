package com.example.ezyfoody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Drinks extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinks);
    }

    public void Order(View view){
        Intent intent = new Intent(this, Order.class);
        startActivity(intent);
    }

    public void MyOrder(View view){
        Intent intent = new Intent(this, MyOrder.class);
        startActivity(intent);
    }

    public void MainActivity(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

}